package com.example.myapplication;

public class AuthUI {
}
