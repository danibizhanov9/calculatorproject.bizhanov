package com.example.myapplication;

public class AppCompatActivity {
}
